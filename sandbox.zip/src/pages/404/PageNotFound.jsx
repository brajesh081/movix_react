import React from 'react'
import './style.scss';

const PageNotFound = () => {
  return (
    <div>PageNotFound</div>
  )
}

export default PageNotFound