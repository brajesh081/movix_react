import React from 'react'
import './style.scss';

const Explore = () => {
  return (
    <div>Explore</div>
  )
}

export default Explore