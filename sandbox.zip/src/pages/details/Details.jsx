import React from 'react'
import './style.scss';


const Details = () => {
  return (
    <div>Details</div>
  )
}

export default Details